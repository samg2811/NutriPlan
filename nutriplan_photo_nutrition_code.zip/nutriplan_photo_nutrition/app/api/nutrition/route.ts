import { NextRequest, NextResponse } from "next/server";
import { getIngredientNutritionPer100g } from "@/lib/usda";

export const runtime = "nodejs";

const nutrientKeys = [
  "calories",
  "protein",
  "carbs",
  "fat",
  "fiber",
  "sugar",
  "sodium",
] as const;

type NutrientKey = (typeof nutrientKeys)[number];
type Nutrition = Record<NutrientKey, number>;

function emptyNutrition(): Nutrition {
  return {
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0,
    fiber: 0,
    sugar: 0,
    sodium: 0,
  };
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const ingredients = body?.ingredients;

    if (!Array.isArray(ingredients) || ingredients.length === 0 || ingredients.length > 50) {
      return NextResponse.json(
        { error: "Provide between 1 and 50 ingredients." },
        { status: 400 }
      );
    }

    for (const ingredient of ingredients) {
      if (
        !ingredient ||
        typeof ingredient.name !== "string" ||
        !ingredient.name.trim() ||
        typeof ingredient.grams !== "number" ||
        !Number.isFinite(ingredient.grams) ||
        ingredient.grams <= 0
      ) {
        return NextResponse.json(
          { error: "Each ingredient must have a name and a positive gram amount." },
          { status: 400 }
        );
      }
    }

    const results = await Promise.all(
      ingredients.map(async (ingredient: { name: string; grams: number; fdcId?: number }) => {
        const per100g = await getIngredientNutritionPer100g(ingredient.name, ingredient.fdcId);
        const factor = ingredient.grams / 100;
        const nutrition = emptyNutrition();
        for (const key of nutrientKeys) {
          nutrition[key] = per100g[key] * factor;
        }
        return {
          name: ingredient.name,
          grams: ingredient.grams,
          nutrition,
        };
      })
    );

    const totals = results.reduce((sum, result) => {
      for (const key of nutrientKeys) sum[key] += result.nutrition[key];
      return sum;
    }, emptyNutrition());

    return NextResponse.json({
      ...Object.fromEntries(
        nutrientKeys.map((key) => [key, Math.round(totals[key] * 10) / 10])
      ),
      ingredients: results,
      source: "USDA FoodData Central",
      note: "Nutrition values are estimates based on USDA matches and the ingredient weights supplied.",
    });
  } catch (error) {
    console.error("Nutrition endpoint error:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not calculate nutrition." },
      { status: 500 }
    );
  }
}
