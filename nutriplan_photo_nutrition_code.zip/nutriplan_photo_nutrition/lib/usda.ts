const NUTRIENT_IDS = {
  calories: 1008,
  protein: 1003,
  fat: 1004,
  carbs: 1005,
  fiber: 1079,
  sugar: 2000,
  sodium: 1093,
} as const;

export type IngredientNutrition = {
  calories: number;
  protein: number;
  fat: number;
  carbs: number;
  fiber: number;
  sugar: number;
  sodium: number;
};

async function searchIngredient(name: string): Promise<number> {
  const apiKey = process.env.USDA_API_KEY;
  if (!apiKey) throw new Error("Missing USDA_API_KEY in environment variables.");

  const url = `https://api.nal.usda.gov/fdc/v1/foods/search?query=${encodeURIComponent(name)}&dataType=Foundation,SR%20Legacy&pageSize=10&api_key=${apiKey}`;
  const response = await fetch(url, { next: { revalidate: 2592000 } });
  if (!response.ok) throw new Error(`USDA search failed for "${name}".`);

  const data = await response.json();
  const foods: { fdcId: number; description?: string }[] = data.foods ?? [];
  if (foods.length === 0) throw new Error(`No USDA match found for "${name}".`);

  const normalizedQuery = name.toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
  const exact = foods.find((food) =>
    (food.description ?? "").toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim() === normalizedQuery
  );
  const contains = foods.find((food) => {
    const description = (food.description ?? "").toLowerCase();
    return description.includes(normalizedQuery) || normalizedQuery.includes(description);
  });

  return (exact ?? contains ?? foods[0]).fdcId;
}

async function getNutrientsPer100g(fdcId: number): Promise<IngredientNutrition> {
  const apiKey = process.env.USDA_API_KEY;
  if (!apiKey) throw new Error("Missing USDA_API_KEY in environment variables.");

  const response = await fetch(
    `https://api.nal.usda.gov/fdc/v1/food/${fdcId}?api_key=${apiKey}`,
    { next: { revalidate: 2592000 } }
  );
  if (!response.ok) throw new Error(`USDA lookup failed for fdcId ${fdcId}.`);

  const data = await response.json();
  const nutrients: IngredientNutrition = {
    calories: 0,
    protein: 0,
    fat: 0,
    carbs: 0,
    fiber: 0,
    sugar: 0,
    sodium: 0,
  };

  for (const item of data.foodNutrients ?? []) {
    const id = item.nutrient?.id ?? item.nutrientId;
    const amount = Number(item.amount ?? item.value ?? 0);
    if (!Number.isFinite(amount)) continue;
    if (id === NUTRIENT_IDS.calories) nutrients.calories = amount;
    if (id === NUTRIENT_IDS.protein) nutrients.protein = amount;
    if (id === NUTRIENT_IDS.fat) nutrients.fat = amount;
    if (id === NUTRIENT_IDS.carbs) nutrients.carbs = amount;
    if (id === NUTRIENT_IDS.fiber) nutrients.fiber = amount;
    if (id === NUTRIENT_IDS.sugar) nutrients.sugar = amount;
    if (id === NUTRIENT_IDS.sodium) nutrients.sodium = amount;
  }

  return nutrients;
}

export async function getIngredientNutritionPer100g(
  name: string,
  fdcId?: number
): Promise<IngredientNutrition> {
  const id = fdcId ?? (await searchIngredient(name));
  return getNutrientsPer100g(id);
}
